
#pragma once
#include "../macros.h"













#define DBUG

#if defined(DBUG)
#include <assert.h>
#include <iostream>
#endif